const express = require('express')
const router = express.Router()
const multer = require('multer');//Importing multer
const path = require('path'); //path module

const restaurantSettingController = require('../controllers/restaurantsetting') //Importing restaurantSetting Controller


// <-- Multer configuration starts from here -->

//setting storage to keep image files
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './uploads/restaurantSetting');
    },
    filename: (req, file, cb) => {
        //console.log(file);
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

//setting filter for image files
const fileFilter = (req, file, cb) => {
    if (file.mimetype == 'image/jpeg' || file.mimetype == 'image/png' || file.mimetype == 'image/gif' || file.mimetype == 'image/bmp') {
        cb(null, true); //Acccepting or storing file
    } else {
        cb(null, false); //Not acccepting or storing file
    }
}

// setting upload
const upload = multer({
    storage: storage,
    //limits: { fileSize: 1024 * 1024 * 5 }, //We can set maximum file size limit too.
    fileFilter: fileFilter
});

// <-- Multer configuration ends here -->


// <-- Routes starts from here -->

//CREATE NEW RESTAURANT SETTING http://localhost:3000/restaurantsetting
router.post('/', upload.array('images', 10), restaurantSettingController.createRestaurantSettingController)

//UPDATE RESTAURANT SETTING http://localhost:3000/restaurantsetting/:ResSetId
router.patch('/:ResSetId', upload.array('images', 10), restaurantSettingController.updateRestaurantSettingController)

//GET RESTAURANT SETTING By ID http://localhost:3000/restaurantsetting/:ResSetId
router.get('/:ResSetId', restaurantSettingController.getRestaurantSettingByIdController)

//GET DEMO RESTAURANT SETTING http://localhost:3000/restaurantsetting/
router.get('/', restaurantSettingController.demoRestaurantSettingController)

// <-- Routes ends here -->



module.exports = router