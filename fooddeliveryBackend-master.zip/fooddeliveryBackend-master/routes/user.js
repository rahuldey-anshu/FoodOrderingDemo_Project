const express = require('express')
const router = express.Router()
const userController = require('../controllers/user') //Importing user controller
const checkauth = require('../middlewares/checkauth') //Authenticate middleware


//SIGNUP http://localhost:3000/user/signup
router.post('/signup', userController.signupController)

//LOGIN http://localhost:3000/user/login
router.post('/login', userController.loginController)

//UPDATE USER INFO http://localhost:3000/user/updateUser/:userid
router.patch('/updateUser/:userid', checkauth, userController.updateUserController)


module.exports = router;