const express = require('express')
const router = express.Router()
const multer = require('multer');//Importing multer
const path = require('path'); //path module

const catagoryController = require('../controllers/catagory')

// <-- Multer configuration starts from here -->

//setting storage to keep image files
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './uploads/catagory');
    },
    filename: (req, file, cb) => {
        //console.log(file);
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

//setting filter for image files
const fileFilter = (req, file, cb) => {
    if (file.mimetype == 'image/jpeg' || file.mimetype == 'image/png' || file.mimetype == 'image/gif' || file.mimetype == 'image/bmp') {
        cb(null, true); //Acccepting or storing file
    } else {
        cb(null, false); //Not acccepting or storing file
    }
}

// setting upload
const upload = multer({
    storage: storage,
    //limits: { fileSize: 1024 * 1024 * 5 }, //We can set maximum file size limit too.
    fileFilter: fileFilter
});

// <-- Multer configuration ends here -->


//ADD NEW CATAGORY  http://localhost:3000/catagory
router.post('/', upload.single('image'), catagoryController.addCatagoryController)

//EDIT CATAGORY  http://localhost:3000/catagory/:catagoryId
router.patch('/:catagoryId', upload.single('image'), catagoryController.editCatagoryController)

//DELETE CATAGORY   http://localhost:3000/catagory/:catagoryId
router.delete('/:catagoryId', catagoryController.deleteCatagoryController)



module.exports = router