const express = require('express')
const router = express.Router()
const appSettingController = require('../controllers/appsetting')


//CREATE NEW APP SETTING http://localhost:3000/appsetting
router.post('/', appSettingController.createAppSettingController)

//UPDATE APP SETTINGS http://localhost:3000/appsetting/:appSettingId
router.patch('/:appSettingId', appSettingController.updateAppSettingController)

//GET APP SETTING BY ID http://localhost:3000/appsetting/:appSettingId
router.get('/:appSettingId', appSettingController.getAppSettingByIdController)

//DEMO http://localhost:3000/appsetting/
router.get('/', appSettingController.demoAppSettingController)



module.exports = router;