const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = Schema({
    fullname: {
        type: String,
        minlength: 3,
        required: [true, "Please enter your name."],
        trim: true
    },
    email: {
        type: String,
        minlength: 4,
        trim: true,
        unique: true,
        required: [true, "Please enter a valid email addres."],
        match: /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/
    },
    password:{
        type: String,
        trim: true,
        required: [true, "Please enter a password."],
        minlength: 4
    },
    address: {
        type: String,
        trim: true
    },
    phone: {
        type: Number,
        trim: true,
        min: [6, "Please enter a valid phone number."]
    }
})

const User = mongoose.model('User', userSchema)

module.exports = User;