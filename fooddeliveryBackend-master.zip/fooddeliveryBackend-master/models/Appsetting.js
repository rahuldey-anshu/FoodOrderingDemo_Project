const mongoose = require('mongoose');

const appSettingSchema = mongoose.Schema({
    numberOfImage: {
        type: Number
    },
    tax: {
        type: Number,
        required: true
    },
    currency: {
        type: String,
        enum: ['INR', 'USD'],
        required: [true, 'Please select a currency']
    },
    minPricePerOrder: {
        type: Number,
        trim: true
    },
    deliveryCharge: {
        type: Number,
        trim: true,
        required: [true, 'Please enter delivery charge'],
        min: [20, 'Minimum delivery charge is 20']
    },
    pincode: {
        type: [Number]
    }
})


const Appsetting = mongoose.model('Appsetting', appSettingSchema)

module.exports = Appsetting;