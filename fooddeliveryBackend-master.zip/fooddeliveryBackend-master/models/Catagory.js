const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const catagorySchema = Schema({
    name: {
        type: String,
        trim: true,
        required: [true, "Please add a name"]
    },
    image: {
        type: String,
        trim: true
    }
})


const Catagory = mongoose.model('Catagory', catagorySchema)

module.exports = Catagory;