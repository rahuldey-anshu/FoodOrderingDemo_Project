const mongoose = require('mongoose');

const restaurantSettingSchema = mongoose.Schema({
    name: {
        type: String,
        trim: true,
        required: [true, "Please enter restaurant name"]
    },
    address: {
        type: String,
        trim: true,
        required: [true, "Please enter restaurant address"]
    },
    description: {
        type: String,
        trim: true
    },
    phone: {
        type: Number,
        trim: true,
        required: [true, "Please enter restaurant phone number"]
    },
    operational_hours: {
        type: String,
        trim: true
    },
    lattitude: {
        type: String,
        trim: true
    },
    longitude: {
        type: String,
        trim: true
    },
    website: {
        type: String,
        trim: true
    },
    images : {
        type: [String]
    }
})


const Restaurantsetting = mongoose.model('Restaurantsetting', restaurantSettingSchema)

module.exports = Restaurantsetting;