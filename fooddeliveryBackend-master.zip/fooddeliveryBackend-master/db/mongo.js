const mongoose = require('mongoose');


//MONGODB CONNECTION
mongoose.connect('mongodb://localhost:27017/restaurent-demo',
    { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false, useCreateIndex: true }, (err) => {
        if (err) throw err;
        console.log('MongoDB is connected');
    })


module.exports = mongoose;