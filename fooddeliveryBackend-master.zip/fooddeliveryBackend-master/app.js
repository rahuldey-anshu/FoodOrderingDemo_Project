const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors')

//Db
const mongo = require('./db/mongo'); //Importing db file
mongo; //Calling db


//MIDDLEWARES
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


//IMPORT ROUTE
const userRoute = require('./routes/user');
const appSettingRroute = require('./routes/appsetting')
const restaurantSettingRroute = require('./routes/restaurantsetting')
const catagoryRoute = require('./routes/catagory')

//INIT ROUTE
app.use('/user', userRoute)
app.use('/appsetting', appSettingRroute)
app.use('/restaurantsetting', restaurantSettingRroute)
app.use('/catagory', catagoryRoute)

//ERROR FOR NON-MATCHING ROUTES
app.use((req, res, next) => {
    const error = new Error('Not found')
    error.status = 404
    next(error)
})
//ERROR HANDLER
app.use((error, req, res, next) => {
    res.status(error.status || 500)
    res.json({
        error: {
            message: error.message
        }
    })
})


//CREATING PORT
const PORT = process.env.PORT || 3000;
//START SERVER WITH PORT
app.listen(PORT, () => { //Creating Server with PORT
    console.log(`Server is running on the port http://localhost:${PORT}`);
})