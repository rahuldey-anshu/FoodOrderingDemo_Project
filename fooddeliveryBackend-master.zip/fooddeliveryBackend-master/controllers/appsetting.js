const Appsetting = require('../models/Appsetting');


createAppSettingController = async (req, res, next) => {
    try {
        //Creating new App setting
        const appSetting = new Appsetting({
            numberOfImage: req.body.numberOfImage,
            tax: req.body.tax,
            currency: req.body.currency,
            minPricePerOrder: req.body.minPricePerOrder,
            deliveryCharge: req.body.deliveryCharge,
            pincode: req.body.pincode
        })
        //Saving appSetting into model
        const newSettings = await appSetting.save()

        res.status(201).json({
            message: "Settings has been saved successfully",
            newSettings
        })

    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}

//UPDATE APP SETTINGS
updateAppSettingController = async (req, res, next) => {
    try {
        const id = req.params.appSettingId //Getting appSettingId from param
        const options = { new: true, runValidators: true } //'new' is used to return updated values, 'runValidators' for validation

        const properties = req.body;
        const updatedSetting = await Appsetting.findByIdAndUpdate(id, { $set: properties }, options) //Saving new settings into AppSetting model

        res.status(201).json({
            message: "Settings has been updated successfully.",
            updatedSetting
        })

    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}


getAppSettingByIdController = async (req, res, next) => {
    try {
        const id = req.params.appSettingId //Getting appSettingId from param

        const appDetails = await Appsetting.findById(id)

        res.status(200).json({
            appDetails
        })
    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }

}


demoAppSettingController = async (req, res, next) => {
    try {
        res.status(200).json({
            message: "Please update all the settings",
            numberOfImage: 10,
            tax: 6,
            currency: "INR",
            minPricePerOrder: 200,
            deliveryCharge: 25,
            pincode: ['00000', '11111', '22222']
        })
    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error
        })
    }
}


module.exports = {
    createAppSettingController,
    getAppSettingByIdController,
    updateAppSettingController,
    demoAppSettingController
}