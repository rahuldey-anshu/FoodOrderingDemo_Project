const User = require('../models/User') //Importing User Model
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')

//SIGNUP
const signupController = async (req, res, next) => {
    try {
        if (req.body.password.length <= 4 ){ //Password Validation
            throw new Error("Password is very short. Enter a strong password")
        }

        //Check User exist or not, if exist then it will show "Sorry! this user..." message.
        const existingUser = await User.find({ email: req.body.email })
        if (existingUser.length !== 0) {
            throw new Error("Sorry! this user already exist")
        }

        //If user does not exist, it will hash its password
        const hashPassword = await bcrypt.hash(req.body.password, 10);
         
        //Creating an user Object
        const user = new User({
            fullname: req.body.fullname,
            email: req.body.email,
            password: hashPassword,
        });
        //Saving new user object into User Model
        const newUser = await user.save()

        const userDetails = { //creating a new object to send as response
            _id: newUser._id,
            fullname: newUser.fullname,
            email: newUser.email
        }

        res.status(201).json({
            message: "Congratulations, Your account has been successfully created.",
            details: userDetails
        })
    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}


//LOGIN
const loginController = async (req, res, next) => {
    try {
        let email = req.body.email
        let password = req.body.password

        //It'll check email exist in db or not
        const user = await User.findOne({ email })

        //if Email Id exist in db
        if (user) {
            bcrypt.compare(password, user.password, (err, result) => {
                if (err) {
                    throw new Error("Authentication failed!")
                }
                if (result) { //If email id & password match
                    let token = jwt.sign({ email: user.email, _id: user._id }, 'SECRET', { expiresIn: '2h' })
                    res.status(200).json({
                        message: "Login successfull! Welcome.",
                        _id: user._id,
                        fullname: user.fullname,
                        token: token
                    })
                } else { //If email id & password does not match
                    res.status(500).json({
                        message: "Authentication failed!"
                    })
                }
            })
        } else { //If emai id does not exist in db
            res.status(500).json({
                message: "Authentication failed!"
            })
        }
    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}


//UPDATE INFO
const updateUserController = async (req, res, next) => {
    try {
        const id = req.params.userid //Getting userid from param
        const options = { new: true, runValidators: true } //'new' is used to return updated values, 'runValidators' for validation

        const properties = req.body;
        const updatedUser = await User.findByIdAndUpdate(id, { $set: properties }, options) //Saving user info into user model

        const details = { //creating an object to return as a response
            _id: updatedUser._id,
            ...properties //Using spread operator
        }

        res.status(201).json({
            message: "User information has been updated successfully.",
            details
        })

    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}



module.exports = {
    signupController,
    loginController,
    updateUserController
}