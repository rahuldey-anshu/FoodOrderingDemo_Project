const Restaurantsetting = require('../models/Restaurantsetting') //Importing Restaurantsetting model
const path = require('path'); //path module

// <-- Controller starts from here -->

createRestaurantSettingController = async (req, res, next) => {
    try {
        if (req.files == 0) {
            throw new Error("Please add at least one image")
        }
        const imagePaths = req.files.map(o => o.path) //only taking the paths of images

        const restaurantDetails = new Restaurantsetting({
            name: req.body.name,
            address: req.body.address,
            description: req.body.description,
            phone: req.body.phone,
            operational_hours: req.body.operational_hours,
            lattitude: req.body.lattitude,
            longitude: req.body.longitude,
            website: req.body.website,
            images: imagePaths
        })
        const newSettings = await restaurantDetails.save()

        res.status(201).json({
            message: "Details has been saved successfully",
            newSettings
        })

    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}

updateRestaurantSettingController = async (req, res, next) => {
    try {
        const id = req.params.ResSetId //Getting ResSetId from param
        const options = { new: true, runValidators: true } //'new' is used to return updated values, 'runValidators' for validation

        if (req.files == 0) { //If there is no image file with update request
            var properties = req.body

        } else { //If update request contains images
            const body = req.body
            const images = req.files.map(o => o.path) //only taking the paths of images

            var properties = { images, ...body } //using spread operator to merge both objects
        }

        const updatedSetting = await Restaurantsetting.findByIdAndUpdate(id, { $set: properties }, options)

        res.status(201).json({
            message: "Details has been updated successfully.",
            updatedSetting
        })

    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}

getRestaurantSettingByIdController = async (req, res, next) => {
    try {
        const id = req.params.ResSetId //Getting ResSetId from param

        const restaurantDetails = await Restaurantsetting.findById(id)

        res.status(200).json({
            restaurantDetails
        })

    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}


//DEMO RESTAURANT SETTING   http://localhost:3000/restaurantsetting/
demoRestaurantSettingController = async (req, res, next) => {
        try {
            res.status(200).json({
            message: "Please update all the settings",
            name: "Enter restaurant name",
            address: "Enter restaurant address",
            description: "Enter restaurant description",
            phone: "00000",
            operational_hours: "Enter restaurant operational hours",
            lattitude: "Enter restaurant lattitude",
            longitude: "Enter restaurant longitude",
            website: "Enter restaurant website",
            })
        } catch (error) {
            res.status(500).json({
                message: "Error occured",
                error: error
            })
        }      
}


// <-- Controllers ends here -->


//Exporting Controllers
module.exports = {
    createRestaurantSettingController,
    updateRestaurantSettingController,
    getRestaurantSettingByIdController,
    demoRestaurantSettingController

}