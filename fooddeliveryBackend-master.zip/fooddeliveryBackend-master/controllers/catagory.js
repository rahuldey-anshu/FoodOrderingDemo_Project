const Catagory = require('../models/Catagory')
const path = require('path'); //path module


//ADD CATAGORY
const addCatagoryController = async (req, res, next) => {
    try {
        if (!req.file) {
            throw new Error("Please add an image")
        }
        const imagePath = req.file.path //Taking the path of image

        const catagory = new Catagory({
            name: req.body.name,
            image: imagePath
        })
        const newCatagory = await catagory.save()

        res.status(201).json({
            message: "Catagory has been added successfully",
            details: newCatagory
        })
    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}


const editCatagoryController = async (req, res, next) => {
    try {
        const id = req.params.catagoryId
        const options = { new: true, runValidators: true } //'new' is used to return updated values, 'runValidators' for validation

        if (!req.file) { //If there is no image file with update request
            var properties = req.body

        } else { //If update request contains image
            const body = req.body
            const image = req.file.path //only taking the paths of images

            var properties = { image, ...body } //using spread operator to merge both objects
        }
        const updatedCatagory = await Catagory.findByIdAndUpdate(id, { $set: properties }, options)

        res.status(201).json({
            message: "Catagory has been updated sucessfully",
            details: updatedCatagory
        })

    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}


const deleteCatagoryController = async (req, res, next) => {
    try {
        const id = req.params.catagoryId

        const remove = await Catagory.remove({ _id: id })
        res.status(202).json({
            message: "Catagory has been deleted"
        })
    } catch (error) {
        res.status(500).json({
            message: "Error occured",
            error: error.message
        })
    }
}


module.exports = {
    addCatagoryController,
    editCatagoryController,
    deleteCatagoryController
}